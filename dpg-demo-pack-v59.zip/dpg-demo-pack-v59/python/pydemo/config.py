# Base URL for DPG services
BASE_URL='https://sbx.corporateapi.db.com'
# Keystore with a client's certificate for 2-way TLS (and password)
TLS_KEYSTORE_FILENAME='../../secret/dpg-demo-pack.dpg.db.com.p12'
TLS_KEYSTORE_PASSWORD='uYOEkClMUt8xZF/Zx8zwzd1y'
# Keystore with a private key for corporate seal (and password)
CS_KEYSTORE_FILENAME='../../secret/dpg-demo-pack.dpg.db.com.p12'
CS_KEYSTORE_PASSWORD='uYOEkClMUt8xZF/Zx8zwzd1y'
PUBLIC_KEY_ID='dpg-demo-pack'
# Marketplace and seller configuration
API_KEY='QHKpnLwngS1RmvhFo5C8xmMTKx66YKaUDCn4aKxiCkHHqA26t2bit33N'
MARKETPLACE_ID='AAEAAAc0ONmMmV_7SqGPDIQS'
MARKETPLACE_SELLER_ID='AAEAAAc0ONmMn2-vnxrwYLMv'
